<div {{ $attributes->merge(['class' => 'w-full']) }}>
  <img src={{ asset('images/logo.png') }} alt="Logo" class="mx-auto">
</div>
