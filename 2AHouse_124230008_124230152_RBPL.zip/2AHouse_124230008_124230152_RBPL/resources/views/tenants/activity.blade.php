<x-app-layout>
  <div class="grid gap-6 p-content">
    <section class="flex flex-col">
      <span class="text-sm text-zinc-500">Activity</span>
      <h1 class="text-lg font-semibold">
        Notification and Messages
      </h1>
    </section>

    <section class="grid gap-4">
    </section>
  </div>
</x-app-layout>
